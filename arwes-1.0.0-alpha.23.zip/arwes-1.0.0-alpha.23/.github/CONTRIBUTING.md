The project is not fully open for sustancial contributions yet until the
first beta version is released. Follow the development on
[Discord](https://discord.gg/s5sbTkw) and [Twitter](https://twitter.com/arwesjs).
