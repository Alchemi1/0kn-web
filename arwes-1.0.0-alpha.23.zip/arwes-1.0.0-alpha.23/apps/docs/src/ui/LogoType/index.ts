export * from './LogoType';
