export type BleepNames =
| 'click'
| 'open'
| 'close'
| 'error'
| 'info'
| 'intro'
| 'content'
| 'type'
| 'assemble';
