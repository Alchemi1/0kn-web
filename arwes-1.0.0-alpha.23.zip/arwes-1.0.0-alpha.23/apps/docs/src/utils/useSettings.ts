import { atomWithStorage } from 'jotai/utils';

export const atomMotion = atomWithStorage('motion', true);

export const atomAudio = atomWithStorage('audio', true);
