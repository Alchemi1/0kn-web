export const GA_TRACKING_ID = 'UA-50433259-2';
