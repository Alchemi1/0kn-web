export * from './getTransitionTextDuration';
