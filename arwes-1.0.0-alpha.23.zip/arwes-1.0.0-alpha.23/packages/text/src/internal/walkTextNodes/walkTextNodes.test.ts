/* eslint-env jest */

test.todo('Should walk element text nodes and call callback with node as argument');
