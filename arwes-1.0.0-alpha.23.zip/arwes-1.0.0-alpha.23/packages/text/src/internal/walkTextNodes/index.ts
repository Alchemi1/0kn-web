export * from './walkTextNodes';
