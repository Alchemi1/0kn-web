/* eslint-env jest */

test.todo('Should set the node children text nodes length as provided new length');

test.todo('Should set the node children text nodes length to empty when new length is 0');

test.todo('Should set the node children text nodes length to empty when new length is total length');
