export * from './createFrameOctagonClip';
