export * from './renderFrameSVGPaths';
