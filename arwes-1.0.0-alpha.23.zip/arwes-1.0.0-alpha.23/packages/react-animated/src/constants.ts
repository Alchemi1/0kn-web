import type { AnimatedSettings } from './types';

export const ANIMATED_ANIMATIONS_EMPTY: Record<string, AnimatedSettings> = Object.freeze({});
