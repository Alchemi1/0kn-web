export * from './formatAnimatedCSSPropsShorthands';
