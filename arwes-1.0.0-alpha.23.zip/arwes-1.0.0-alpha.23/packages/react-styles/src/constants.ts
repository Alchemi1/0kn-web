import type { Styles } from './types';

export const STYLES_EMPTY: Styles = Object.freeze({});
