import { memo } from '@arwes/react-tools';
import { FrameSVGLines as Component } from './FrameSVGLines';

const FrameSVGLines = memo(Component);

export * from './FrameSVGLines';
export { FrameSVGLines };
