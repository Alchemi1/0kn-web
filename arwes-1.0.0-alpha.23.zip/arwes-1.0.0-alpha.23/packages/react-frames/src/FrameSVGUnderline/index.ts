import { memo } from '@arwes/react-tools';
import { FrameSVGUnderline as Component } from './FrameSVGUnderline';

const FrameSVGUnderline = memo(Component);

export * from './FrameSVGUnderline';
export { FrameSVGUnderline };
