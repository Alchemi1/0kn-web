import { memo } from '@arwes/react-tools';
import { FrameSVGOctagon as Component } from './FrameSVGOctagon';

const FrameSVGOctagon = memo(Component);

export * from './FrameSVGOctagon';
export { FrameSVGOctagon };
