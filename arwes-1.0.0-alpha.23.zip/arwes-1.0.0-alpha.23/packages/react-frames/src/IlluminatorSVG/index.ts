import { memo } from '@arwes/react-tools';
import { IlluminatorSVG as Component } from './IlluminatorSVG';

const IlluminatorSVG = memo(Component);

export * from './IlluminatorSVG';
export { IlluminatorSVG };
