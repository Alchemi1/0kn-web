import { memo } from '@arwes/react-tools';
import { FrameSVGNefrex as Component } from './FrameSVGNefrex';

const FrameSVGNefrex = memo(Component);

export * from './FrameSVGNefrex';
export { FrameSVGNefrex };
