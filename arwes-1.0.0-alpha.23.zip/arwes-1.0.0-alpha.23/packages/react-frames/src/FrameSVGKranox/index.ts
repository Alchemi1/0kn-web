import { memo } from '@arwes/react-tools';
import { FrameSVGKranox as Component } from './FrameSVGKranox';

const FrameSVGKranox = memo(Component);

export * from './FrameSVGKranox';
export { FrameSVGKranox };
