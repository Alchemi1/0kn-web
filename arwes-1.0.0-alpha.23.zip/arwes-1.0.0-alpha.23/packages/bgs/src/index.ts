export const ARWES_BGS = '@arwes/bgs';
